package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.NumberFormat;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    double num1;
    String operacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void clique_numero(View view) {
        Button b = (Button) view;
        int digito = Integer.valueOf(b.getText().toString());

        EditText visor = findViewById(R.id.visor);
        String atual = visor.getText().toString();

        if(!atual.equals("0"))
            visor.setText(atual + digito);
        else
            visor.setText(String.valueOf(digito));
    }

    public void clique_operador(View view) {
        Button b = (Button) view;
        EditText visor = findViewById(R.id.visor);
        String atual = visor.getText().toString();

        num1 = Double.parseDouble(atual);
        operacao = b.getText().toString();
        atual = "0";

        visor.setText(atual);
    }

    public void clique_ponto(View view) {
        Button b = (Button) view;
        EditText visor = findViewById(R.id.visor);
        String atual = visor.getText().toString();

        if(!visor.getText().toString().contains("."))
            visor.setText(atual + ".");
    }

    public void limpar_visor(View view) {
        Button b = (Button) view;
        EditText visor = findViewById(R.id.visor);
        visor.setText("0");
    }

    public void backspace(View view) {
        Button b = (Button) view;
        EditText visor = findViewById(R.id.visor);
        String atual = visor.getText().toString();

        if(visor.getText().length() > 1) {
            atual = atual.substring(0, atual.length() - 1);
            visor.setText(atual);
        } else
            visor.setText("0");
    }

    public void resultado(View view) {
        Button b = (Button) view;
        EditText visor = findViewById(R.id.visor);
        String atual = visor.getText().toString();

        double num2 = Double.parseDouble(visor.getText().toString());
        double resultado = 0;

        switch(operacao) {
            case "+":
                resultado = num1 + num2;
                break;

            case "-":
                resultado = num1 - num2;
                break;

            case "x":
                resultado = num1 * num2;
                break;

            case "/":
                resultado = num1 / num2;
                break;

            default: // Caso o usuário já clique no '=' sem operação
                resultado = 0;
        }

        atual = String.valueOf(resultado);
        visor.setText(atual);
        num1 = resultado;
    }
}